#!/bin/sh

lua exportReadme.lua -OS -i readmes -o .. -f modlists