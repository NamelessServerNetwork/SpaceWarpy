# Warpy  
Warpy is a modpack with focus on Warpdrive.  
The pack is designed for our public server, but can be used standalone too.

On our server you have the possibility to access OpenComputers disks using an FTP connection. This way you can code directly on the server using your preferred editor/IDE.

If you want to join the project we recommend you to join our [Discord server](https://discord.gg/v927kk7) too. There you can talk with us and get news about Warpy as well as server events.

MC server: warpy.namelessys.de  
Discord server: [https://discord.gg/v927kk7](https://discord.gg/v927kk7)  
Modpack (GitHub): [URL)  

# Optifine
We strongly recommend anyone to install optifine.
Unfortunately we are not allowed to add it to our modpack.
So you have to install it by yourself.

Optifine: [https://optifine.net/adloadx?f=OptiFine_1.12.2_HD_U_F5.jar](https://optifine.net/adloadx?f=OptiFine_1.12.2_HD_U_F5.jar)  

[MODLIST]

We hope you like that project, and we see you on the server :).
 